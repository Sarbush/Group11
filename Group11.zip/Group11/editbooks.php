<?php

require_once ('includes/header.php');
require_once('includes/database.php');

if(filter_has_var(INPUT_GET, 'id')){
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_STRING);   
}

//SQL query
$sql = "SELECT * FROM posts WHERE id = '$id'";
        
$query = $conn->query($sql);

if(!query){
 $errno = $conn->errno;
 $errmsg = $conn->error;
 echo "Selection failed with: ($errno) $errmsg";
 $conn->close();
 exit;   
}

$row = $query->fetch_assoc()

?>

<form action="editbooks_db.php" method="post">
    <table cellspacing="0" cellpadding="3" style="border: 1px solid silver; padding:5px; margin-bottom: 10px">
        <tr>
            <td style="text-align: right; width: 100px">Title: </td>
            <td><input name="Title" type="text" size="100" value="<?php echo $row['Title'] ?>" /></td>
        </tr>
        <tr>
            <td style="text-align: right">Author: </td>
            <td><input name="Author" type="text" size="40" value="<?php echo $row['Author'] ?>"/></td>
        </tr>
        <tr>
            <td style="text-align: right">Publish date: </td>
            <td>
                <input name="Year Published" type="text" pattern="[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])" value="<?php echo $row['Year Published'] ?>" />
                <span style="font-size: small">YYYY-MM-DD</span>
            </td>
        </tr>
        <tr>
            <td style="text-align: right">Genre: </td>
            <td><input name="Genre" type="text" size="40" value="<?php echo $row['Genre'] ?>"/></td>
        </tr>
        <tr>
          <tr>
            <td style="text-align: right">Reading Level:</td>
            <td>
                <select name="Reading Level">
                    <option value="1">Elementary School/option>
                    <option value="2">Middle School</option>
                    <option value="3">High School</option>
                
                </select>
            </td>
        </tr>
    </table>
    
    <input type="hidden" value="<?php echo $row['id'] ?>">
    <input type="submit" value="Edit">
</form> 


<?php 
include ('includes/footer.php');

