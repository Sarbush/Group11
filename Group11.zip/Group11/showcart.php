<?php


$page_title = "Shopping Cart";
require_once ('includes/header.php');
require_once('includes/database.php');

?>
<h2>My Shopping Cart</h2>
<?php
if (!isset($_SESSION['cart']) || !$_SESSION['cart']) {
    echo "Your shopping cart is empty.<br><br>";
    include ('includes/footer.php');
    exit();
}

//proceed since the cart is not empty
$cart = $_SESSION['cart'];

//print_r($cart);
?>
<table class="booklist">
    <tr>
        <th>Title</th>
            <th class="col2">Author</th>
            <th class="col3">Year Published</th>
            <th class="col4">Genre</th>
            <th class="col4">Reading Level</th>
    </tr>
    <?php
    //insert code to display the shopping cart content
    //select statement
    $sql = "SELECT * FROM books WHERE 0";
    foreach (array_keys($cart) as $id) {
        $sql .= " OR id=$id";
    }

    //echo $sql;
    
    $query = @$conn->query($sql);
    // add an error handle
    
    //
    while($row = $query->fetch_assoc()){
        echo "<tr>";
            echo "<td><a href='bookdetails.php?id=", $row['id'], "'>", $row['Title'], "</a></td>";
            echo "<td>", $row['Author'], "</td>";
            echo "<td>", $row['Year Published'], "</td>";
            echo "<td>", $row['Genre'], "</td>";
            echo "<td>", $row['Reading Level'], "</td>";
            echo "</tr>";      
        
    }
    
    ?>
</table>
<br>
<div class="bookstore-button">
    <input type="button" value="Checkout" onclick="window.location.href = 'checkout.php'"/>
    <input type="button" value="Cancel" onclick="window.location.href = 'listbooks.php'" />
</div>
<br><br>

<?php
include ('includes/footer.php');

