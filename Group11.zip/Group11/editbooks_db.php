<?php

require_once('includes/database.php');

if(filter_has_var(INPUT_GET, 'id')){
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_STRING);   
}

if(filter_has_var(INPUT_GET, 'Title')){
    $title = filter_input(INPUT_GET, 'Title', FILTER_SANITIZE_STRING);   
}
