<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (isset($_SESSION['cart'])) {
    $cart = $_SESSION['cart'];
} else {
    $cart = array();
}
//print_r($cart);
//if book id cannot be found, terminate script.
if (!filter_has_var(INPUT_GET, 'id')) {
    $error = "Book id not found. Operation cannot proceed.<br><br>";
    header("Location: error.php?m=$error");
    die();
}

//retrieve book id and make sure it is a numeric value.
$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
//echo "id is", $id;
if (!is_numeric($id)) {
    $error = "Invalid book id. Operation cannot proceed.<br><br>";
    header("Location: error.php?m=$error");
    die();
}

if (array_key_exists($id, $cart)) {
    $cart[$id] = $cart[$id] + 1;
} else {
    $cart[$id] = 1;
}

//update the session variable
$_SESSION['cart'] = $cart;

//print_r($_SESSION['cart']);

//redirect to the showcart.php page.
header('Location: showcart.php');
?>
<div class="bookstore-button">
    <input type="submit" value="Add Item" />
    <input type="button" value="Cancel" onclick="window.location.href = 'listbooks.php'" />
</div>




