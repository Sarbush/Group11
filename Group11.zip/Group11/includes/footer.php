<div id="footer">
                <hr>
                <p>&copy; PHP Library Rental. All Rights Reserved.</p>
            </div>
        </div>
    </body>
</html>

